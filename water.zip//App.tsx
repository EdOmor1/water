import React, { useState, useMemo } from 'react';

type WaterAssetType =
  | 'Water Rights'
  | 'Physical Water'
  | 'Water Credits'
  | 'Water Futures'
  | 'Infrastructure'
  | 'Tokenized'
  | 'Ice Assets';

interface WaterAsset {
  id: string;
  name: string;
  type: WaterAssetType;
  region: string;
  subType: string;
  currentPrice?: number; // Optional, for spot/futures
  volume?: number; // Optional, for physical
  unit?: string; // e.g., ML, Credit, Share, Token
  expiry?: string; // Optional, for temporary rights/futures
}

// Mock Data representing diverse assets from the prompt
const initialAssets: WaterAsset[] = [
  { id: 'wr001', name: 'Thames Basin - Permanent Consumptive Right', type: 'Water Rights', region: 'London, UK', subType: 'Permanent', currentPrice: 1500, unit: 'ML/yr' },
  { id: 'wr002', name: 'Seasonal Irrigation Lease - Kent', type: 'Water Rights', region: 'Kent, UK', subType: 'Seasonal Lease', currentPrice: 300, unit: 'ML', expiry: '2024-09-30' },
  { id: 'pw001', name: 'Treated Municipal Water Delivery', type: 'Physical Water', region: 'London, UK', subType: 'Treated', currentPrice: 2.5, unit: 'm³' },
  { id: 'wc001', name: 'UK Habitat Restoration Credit', type: 'Water Credits', region: 'National, UK', subType: 'Restoration', currentPrice: 50, unit: 'Credit' },
  { id: 'wc002', name: 'Industrial Water Efficiency Offset', type: 'Water Credits', region: 'Midlands, UK', subType: 'Efficiency Offset', currentPrice: 45, unit: 'Credit' },
  { id: 'wf001', name: 'UK Water Index Future - Dec 2024', type: 'Water Futures', region: 'National, UK', subType: 'Index Future', currentPrice: 105.5, unit: 'Index Pt', expiry: '2024-12-20' },
  { id: 'in001', name: 'Fractional Share - London Desalination Plant', type: 'Infrastructure', region: 'London, UK', subType: 'Desalination Plant', currentPrice: 5000, unit: 'Share' },
  { id: 'tk001', name: 'Tokenized Lee Valley Reservoir Right', type: 'Tokenized', region: 'London, UK', subType: 'NFT Water License', currentPrice: 1.2, unit: 'ETH (equiv.)' },
  { id: 'ia001', name: 'Scottish Highland Snowpack Allocation (Future)', type: 'Ice Assets', region: 'Scotland, UK', subType: 'Snowpack Allocation', unit: 'ML (Est.)', expiry: '2025-Spring' },
];

const AssetTypePill: React.FC<{ type: WaterAssetType }> = ({ type }) => {
  const typeColors: Record<WaterAssetType, string> = {
    'Water Rights': 'bg-blue-100 text-blue-800',
    'Physical Water': 'bg-cyan-100 text-cyan-800',
    'Water Credits': 'bg-green-100 text-green-800',
    'Water Futures': 'bg-yellow-100 text-yellow-800',
    'Infrastructure': 'bg-gray-100 text-gray-800',
    'Tokenized': 'bg-purple-100 text-purple-800',
    'Ice Assets': 'bg-sky-100 text-sky-800',
  };
  return (
    <span className={`px-2 py-0.5 text-xs font-medium rounded-full ${typeColors[type]}`}>
      {type}
    </span>
  );
};

const LondonWaterExchangeImproved: React.FC = () => {
  const [assets, setAssets] = useState<WaterAsset[]>(initialAssets);
  const [selectedType, setSelectedType] = useState<WaterAssetType | 'All'>('All');
  const [searchTerm, setSearchTerm] = useState<string>('');
  const [selectedAsset, setSelectedAsset] = useState<WaterAsset | null>(null);

  const assetTypes: WaterAssetType[] = useMemo(() => [
    'Water Rights',
    'Physical Water',
    'Water Credits',
    'Water Futures',
    'Infrastructure',
    'Tokenized',
    'Ice Assets',
  ], []);

  const filteredAssets = useMemo(() => {
    return assets.filter(asset => {
      const typeMatch = selectedType === 'All' || asset.type === selectedType;
      const searchMatch = searchTerm === '' ||
        asset.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        asset.region.toLowerCase().includes(searchTerm.toLowerCase()) ||
        asset.subType.toLowerCase().includes(searchTerm.toLowerCase());
      return typeMatch && searchMatch;
    });
  }, [assets, selectedType, searchTerm]);

  const handleSelectAsset = (asset: WaterAsset) => {
    setSelectedAsset(asset);
    // In a real app, this might open a trading modal or detail view
    console.log("Selected Asset:", asset);
  };

  return (
    <div className="p-4 md:p-6 lg:p-8 bg-gradient-to-br from-blue-50 via-white to-cyan-50 min-h-screen font-sans">
      <div className="max-w-7xl mx-auto">
        <header className="mb-6 md:mb-8">
          <h1 className="text-2xl md:text-3xl font-bold text-blue-900">London Water Exchange</h1>
          <p className="text-sm text-gray-600 mt-1">Enhanced Asset Explorer & Trading Interface</p>
        </header>

        {/* Filters and Search Section */}
        <div className="mb-6 p-4 bg-white rounded-lg shadow-md">
          <div className="flex flex-col md:flex-row md:items-center gap-4">
            <div className="flex-grow">
              <label htmlFor="search" className="block text-sm font-medium text-gray-700 mb-1">Search Assets</label>
              <input
                type="text"
                id="search"
                placeholder="Search by name, region, type..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              />
            </div>
            <div className="md:w-auto">
              <label htmlFor="assetType" className="block text-sm font-medium text-gray-700 mb-1">Filter by Type</label>
              <select
                id="assetType"
                value={selectedType}
                onChange={(e) => setSelectedType(e.target.value as WaterAssetType | 'All')}
                className="w-full md:w-auto px-3 py-2 border border-gray-300 bg-white rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
              >
                <option value="All">All Asset Types</option>
                {assetTypes.map(type => (
                  <option key={type} value={type}>{type}</option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {/* Asset Listing Table */}
        <div className="bg-white rounded-lg shadow-md overflow-hidden">
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead className="bg-gray-50">
                <tr>
                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Asset Name</th>
                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider hidden md:table-cell">Region</th>
                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                  <th scope="col" className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider hidden sm:table-cell">Sub-Type</th>
                  <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Price/Value</th>
                  <th scope="col" className="px-4 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Unit</th>
                  <th scope="col" className="px-4 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Action</th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {filteredAssets.length > 0 ? filteredAssets.map((asset) => (
                  <tr key={asset.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{asset.name}</div>
                      {asset.expiry && <div className="text-xs text-red-600 hidden sm:block">Expires: {asset.expiry}</div>}
                    </td>
                     <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500 hidden md:table-cell">{asset.region}</td>
                    <td className="px-4 py-3 whitespace-nowrap">
                      <AssetTypePill type={asset.type} />
                    </td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500 hidden sm:table-cell">{asset.subType}</td>
                    <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-900 text-right font-medium">
                      {asset.currentPrice !== undefined ? `${asset.currentPrice.toLocaleString()}` : 'N/A'}
                    </td>
                     <td className="px-4 py-3 whitespace-nowrap text-sm text-gray-500 text-right">{asset.unit ?? 'N/A'}</td>
                    <td className="px-4 py-3 whitespace-nowrap text-center text-sm font-medium">
                      <button
                        onClick={() => handleSelectAsset(asset)}
                        className="text-blue-600 hover:text-blue-800 bg-blue-100 hover:bg-blue-200 px-3 py-1 rounded-md text-xs transition duration-150 ease-in-out"
                      >
                        Trade
                      </button>
                    </td>
                  </tr>
                )) : (
                  <tr>
                    <td colSpan={7} className="px-6 py-10 text-center text-sm text-gray-500">
                      No assets found matching your criteria.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>

        {/* Simple Selected Asset Display (Placeholder for Trade Modal/Detail View) */}
        {selectedAsset && (
          <div className="mt-6 p-4 bg-white rounded-lg shadow-lg border border-blue-200">
            <h3 className="text-lg font-semibold text-blue-800 mb-2">Selected Asset Details</h3>
            <p><span className="font-medium">Name:</span> {selectedAsset.name}</p>
            <p><span className="font-medium">Type:</span> {selectedAsset.type} ({selectedAsset.subType})</p>
            <p><span className="font-medium">Region:</span> {selectedAsset.region}</p>
            <p><span className="font-medium">Price/Value:</span> {selectedAsset.currentPrice?.toLocaleString() ?? 'N/A'} {selectedAsset.unit}</p>
            {selectedAsset.expiry && <p><span className="font-medium">Expiry:</span> {selectedAsset.expiry}</p>}
            <button
                onClick={() => setSelectedAsset(null)}
                className="mt-4 text-sm text-gray-600 hover:text-gray-800"
            >
                Close Details
            </button>
          </div>
        )}

        {/* Placeholder for Advanced Features/Improvements */}
        <div className="mt-8 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <div className="bg-white p-4 rounded-lg shadow hover:shadow-lg transition-shadow duration-200 border border-gray-100">
                <h4 className="font-semibold text-blue-700 mb-2">Improvement Idea: NLP Order Entry</h4>
                <p className="text-sm text-gray-600">Integrate natural language processing to allow orders like: "Buy 10 ML Thames Permanent Rights"</p>
                 <div className="mt-3 bg-gray-100 border border-dashed rounded-lg p-3 text-xs text-gray-500">Feature Mockup Area</div>
            </div>
            <div className="bg-white p-4 rounded-lg shadow hover:shadow-lg transition-shadow duration-200 border border-gray-100">
                <h4 className="font-semibold text-green-700 mb-2">Improvement Idea: Enhanced Credit Tracking</h4>
                <p className="text-sm text-gray-600">Visualize water credit balances, track offset impact, and link to ESG reporting standards.</p>
                 <div className="mt-3 bg-gray-100 border border-dashed rounded-lg p-3 text-xs text-gray-500">Feature Mockup Area</div>
            </div>
            <div className="bg-white p-4 rounded-lg shadow hover:shadow-lg transition-shadow duration-200 border border-gray-100">
                <h4 className="font-semibold text-purple-700 mb-2">Improvement Idea: Tokenized Asset Wallet</h4>
                <p className="text-sm text-gray-600">Dedicated interface for managing tokenized water rights/NFTs, showing on-chain transaction history.</p>
                 <div className="mt-3 bg-gray-100 border border-dashed rounded-lg p-3 text-xs text-gray-500">Feature Mockup Area</div>
            </div>
        </div>

      </div>
    </div>
  );
};

export default LondonWaterExchangeImproved;