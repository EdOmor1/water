import React, { useState, useEffect } from 'react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

// --- Mock Data Types ---
type WaterAssetType =
  | 'Water Right - Permanent'
  | 'Water Right - Temporary'
  | 'Physical Water - Raw'
  | 'Physical Water - Treated'
  | 'Water Credit - Efficiency'
  | 'Water Credit - Offset'
  | 'Water Future - Index'
  | 'Tokenized Right - NFT'
  | 'Infrastructure - Reservoir Share'
  | 'Geographic - Basin License'
  | 'Ice - Glacial Meltwater';

interface WaterAsset {
  id: string;
  name: string;
  type: WaterAssetType;
  region: string;
  volume?: number; // Megalitres (ML) or similar unit
  unit: string; // e.g., 'ML', 'Credit', 'Share', 'Contract', 'NFT'
  price: number; // Price per unit
  available: number; // Quantity available
  expiry?: string; // For temporary rights/futures
}

interface PortfolioItem {
  assetId: string;
  assetName: string;
  assetType: WaterAssetType;
  quantity: number;
  avgBuyPrice: number;
  currentValue: number;
}

interface TradeHistoryItem {
  id: string;
  date: string;
  type: 'Buy' | 'Sell' | 'Lease';
  assetName: string;
  quantity: number;
  price: number;
  total: number;
}

interface UserProfile {
  name: string;
  email: string;
  kycStatus: 'Pending' | 'Verified' | 'Rejected';
  waterBalanceML: number;
  creditBalance: number;
}

// --- Mock Data ---
const mockAssets: WaterAsset[] = [
  { id: 'wrp001', name: 'Thames Basin Permanent Right', type: 'Water Right - Permanent', region: 'London', volume: 100, unit: 'ML', price: 5000, available: 5 },
  { id: 'wrt002', name: 'Summer Irrigation Lease (Lea Valley)', type: 'Water Right - Temporary', region: 'London', volume: 50, unit: 'ML', price: 300, available: 20, expiry: '2024-09-30' },
  { id: 'pwr003', name: 'Bulk Raw Water (Reservoir Alpha)', type: 'Physical Water - Raw', region: 'London', unit: 'ML', price: 50, available: 10000 },
  { id: 'pwt004', name: 'Treated Municipal Supply Contract', type: 'Physical Water - Treated', region: 'London', unit: 'ML', price: 150, available: 5000 },
  { id: 'wce005', name: 'Industrial Efficiency Credit', type: 'Water Credit - Efficiency', region: 'UK Wide', unit: 'Credit', price: 80, available: 1000 },
  { id: 'wco006', name: 'Wetland Restoration Offset', type: 'Water Credit - Offset', region: 'Kent', unit: 'Credit', price: 120, available: 500 },
  { id: 'wfi007', name: 'UK Water Index Future (Dec 2024)', type: 'Water Future - Index', region: 'UK Wide', unit: 'Contract', price: 1150, available: 200, expiry: '2024-12-20' },
  { id: 'trn008', name: 'Tokenized Severn Bore Right #042', type: 'Tokenized Right - NFT', region: 'Severn', unit: 'NFT', price: 12000, available: 1 },
  { id: 'irs009', name: 'Share in Queen Mary Reservoir', type: 'Infrastructure - Reservoir Share', region: 'London', unit: 'Share', price: 25000, available: 15 },
  { id: 'gbl010', name: 'Lower Thames Abstraction License', type: 'Geographic - Basin License', region: 'London', unit: 'License', price: 7500, available: 8 },
  { id: 'igm011', name: 'Scottish Glacial Meltwater Allocation (Spring 25)', type: 'Ice - Glacial Meltwater', region: 'Scotland', volume: 10, unit: 'ML', price: 900, available: 30, expiry: '2025-06-30' },
];

const mockPortfolio: PortfolioItem[] = [
  { assetId: 'wrp001', assetName: 'Thames Basin Permanent Right', assetType: 'Water Right - Permanent', quantity: 1, avgBuyPrice: 4800, currentValue: 5000 },
  { assetId: 'wce005', assetName: 'Industrial Efficiency Credit', assetType: 'Water Credit - Efficiency', quantity: 50, avgBuyPrice: 75, currentValue: 4000 },
];

const mockTradeHistory: TradeHistoryItem[] = [
  { id: 'th001', date: '2023-11-15', type: 'Buy', assetName: 'Thames Basin Permanent Right', quantity: 1, price: 4800, total: 4800 },
  { id: 'th002', date: '2023-11-20', type: 'Buy', assetName: 'Industrial Efficiency Credit', quantity: 50, price: 75, total: 3750 },
  { id: 'th003', date: '2023-11-25', type: 'Sell', assetName: 'Summer Irrigation Lease (Lea Valley)', quantity: 10, price: 310, total: 3100 },
];

const mockUserProfile: UserProfile = {
  name: 'Alice Wonderland',
  email: 'alice@example.com',
  kycStatus: 'Verified',
  waterBalanceML: 150,
  creditBalance: 50,
};

const mockMarketData = [
  { name: 'Jan', price: 1100 },
  { name: 'Feb', price: 1120 },
  { name: 'Mar', price: 1110 },
  { name: 'Apr', price: 1150 },
  { name: 'May', price: 1180 },
  { name: 'Jun', price: 1200 },
  { name: 'Jul', price: 1190 },
  { name: 'Aug', price: 1210 },
  { name: 'Sep', price: 1250 },
  { name: 'Oct', price: 1230 },
  { name: 'Nov', price: 1150 },
];

// --- Components ---

// Navbar Component
const Navbar: React.FC<{ setPage: (page: string) => void; currentPage: string }> = ({ setPage, currentPage }) => {
  const navItems = ['Dashboard', 'Marketplace', 'Trade', 'Portfolio', 'Analytics', 'Account', 'Admin'];
  const baseStyle = "px-4 py-2 rounded-md text-sm font-medium transition-colors duration-150";
  const activeStyle = "bg-blue-600 text-white";
  const inactiveStyle = "text-gray-700 hover:bg-blue-100 hover:text-blue-700";

  return (
    <nav className="bg-white shadow-md mb-6">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <div className="flex-shrink-0 text-blue-600 font-bold text-xl">
              💧 WaterTradeX
            </div>
            <div className="hidden md:block">
              <div className="ml-10 flex items-baseline space-x-4">
                {navItems.map((item) => (
                  <button
                    key={item}
                    onClick={() => setPage(item)}
                    className={`${baseStyle} ${currentPage === item ? activeStyle : inactiveStyle}`}
                  >
                    {item}
                  </button>
                ))}
              </div>
            </div>
          </div>
          {/* Mobile menu button could be added here */}
        </div>
      </div>
    </nav>
  );
};

// Dashboard Page
const DashboardPage: React.FC = () => {
  const highlights = mockAssets.slice(0, 3); // Show top 3 assets as highlights

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-800">Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white p-4 rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-700 mb-2">Water Balance</h3>
          <p className="text-2xl font-semibold text-blue-600">{mockUserProfile.waterBalanceML} <span className="text-sm font-normal text-gray-500">ML</span></p>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-700 mb-2">Credit Balance</h3>
          <p className="text-2xl font-semibold text-green-600">{mockUserProfile.creditBalance} <span className="text-sm font-normal text-gray-500">Credits</span></p>
        </div>
        <div className="bg-white p-4 rounded-lg shadow">
          <h3 className="text-lg font-medium text-gray-700 mb-2">Portfolio Value</h3>
          <p className="text-2xl font-semibold text-gray-800">£{mockPortfolio.reduce((sum, item) => sum + item.currentValue, 0).toLocaleString()}</p>
        </div>
      </div>

      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-xl font-semibold text-gray-800 mb-4">Market Highlights</h2>
        <div className="space-y-4">
          {highlights.map(asset => (
            <div key={asset.id} className="flex justify-between items-center p-3 border rounded-md hover:bg-gray-50">
              <div>
                <p className="font-medium text-gray-900">{asset.name} ({asset.region})</p>
                <p className="text-sm text-gray-500">{asset.type}</p>
              </div>
              <div className="text-right">
                <p className="font-semibold text-blue-600">£{asset.price.toLocaleString()} / {asset.unit}</p>
                <p className="text-sm text-gray-500">Available: {asset.available}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

        <div className="bg-white p-6 rounded-lg shadow">
             <h2 className="text-xl font-semibold text-gray-800 mb-4">Recent Activity</h2>
             <ul className="space-y-2">
                {mockTradeHistory.slice(0,3).map(trade => (
                    <li key={trade.id} className="text-sm text-gray-600 border-b pb-1">
                        <span className={`font-medium ${trade.type === 'Buy' ? 'text-green-600' : 'text-red-600'}`}>{trade.type}</span> {trade.quantity} {trade.assetName.split('(')[0]} @ £{trade.price} on {trade.date}
                    </li>
                ))}
             </ul>
        </div>
    </div>
  );
};

// Marketplace Page
const MarketplacePage: React.FC<{ setSelectedAsset: (asset: WaterAsset | null) => void; setPage: (page: string) => void }> = ({ setSelectedAsset, setPage }) => {
  const [filterType, setFilterType] = useState<string>('All');
  const [filterRegion, setFilterRegion] = useState<string>('All');
  const [searchTerm, setSearchTerm] = useState<string>('');

  const assetTypes = ['All', ...new Set(mockAssets.map(a => a.type))];
  const regions = ['All', ...new Set(mockAssets.map(a => a.region))];

  const filteredAssets = mockAssets.filter(asset =>
    (filterType === 'All' || asset.type === filterType) &&
    (filterRegion === 'All' || asset.region === filterRegion) &&
    (searchTerm === '' || asset.name.toLowerCase().includes(searchTerm.toLowerCase()) || asset.id.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handleTradeClick = (asset: WaterAsset) => {
    setSelectedAsset(asset);
    setPage('Trade');
  };

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-800">Marketplace</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6 bg-white p-4 rounded-lg shadow-sm">
        <div>
          <label htmlFor="assetTypeFilter" className="block text-sm font-medium text-gray-700">Asset Type</label>
          <select id="assetTypeFilter" value={filterType} onChange={(e) => setFilterType(e.target.value)} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md">
            {assetTypes.map(type => <option key={type} value={type}>{type}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="regionFilter" className="block text-sm font-medium text-gray-700">Region</label>
          <select id="regionFilter" value={filterRegion} onChange={(e) => setFilterRegion(e.target.value)} className="mt-1 block w-full pl-3 pr-10 py-2 text-base border-gray-300 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm rounded-md">
            {regions.map(region => <option key={region} value={region}>{region}</option>)}
          </select>
        </div>
        <div>
          <label htmlFor="searchFilter" className="block text-sm font-medium text-gray-700">Search</label>
           <input
            type="text"
            id="searchFilter"
            placeholder="Search by name or ID..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
           />
        </div>
      </div>

      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <ul role="list" className="divide-y divide-gray-200">
          {filteredAssets.map((asset) => (
            <li key={asset.id} className="px-4 py-4 sm:px-6 hover:bg-gray-50">
              <div className="flex items-center justify-between">
                <div className="truncate">
                  <div className="flex text-sm">
                    <p className="font-medium text-blue-600 truncate">{asset.name}</p>
                    <p className="ml-1 flex-shrink-0 font-normal text-gray-500">({asset.region})</p>
                  </div>
                  <div className="mt-1 flex">
                    <p className="text-sm text-gray-600">{asset.type} - ID: {asset.id}</p>
                  </div>
                </div>
                <div className="ml-5 flex-shrink-0 flex flex-col items-end space-y-1">
                  <p className="text-sm font-semibold text-gray-900">£{asset.price.toLocaleString()} <span className="text-xs font-normal text-gray-500">/ {asset.unit}</span></p>
                  <p className="text-xs text-gray-500">Available: {asset.available} {asset.unit}s</p>
                  {asset.expiry && <p className="text-xs text-red-500">Expires: {asset.expiry}</p>}
                   <button
                      onClick={() => handleTradeClick(asset)}
                      className="mt-1 px-3 py-1 bg-blue-500 text-white text-xs font-medium rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    >
                      Trade
                    </button>
                </div>
              </div>
            </li>
          ))}
        </ul>
         {filteredAssets.length === 0 && (
            <div className="text-center py-10 px-4 sm:px-6">
                <p className="text-sm font-medium text-gray-500">No assets found matching your criteria.</p>
            </div>
         )}
      </div>
    </div>
  );
};

// Trading Page
const TradingPage: React.FC<{ selectedAsset: WaterAsset | null }> = ({ selectedAsset }) => {
  const [tradeType, setTradeType] = useState<'Buy' | 'Sell'>('Buy');
  const [orderType, setOrderType] = useState<'Market' | 'Limit'>('Market');
  const [quantity, setQuantity] = useState<number>(1);
  const [limitPrice, setLimitPrice] = useState<number | ''>('');
  const [message, setMessage] = useState<string>('');

  const handlePlaceOrder = () => {
    if (!selectedAsset) {
        setMessage("Error: No asset selected.");
        return;
    }
    // Basic validation
    if (quantity <= 0) {
        setMessage("Error: Quantity must be positive.");
        return;
    }
    if (orderType === 'Limit' && (limitPrice === '' || limitPrice <= 0)) {
        setMessage("Error: Limit price must be positive for Limit orders.");
        return;
    }
     if (tradeType === 'Buy' && quantity > selectedAsset.available) {
        setMessage(`Error: Not enough quantity available (Max: ${selectedAsset.available}).`);
        return;
    }
    // TODO: Add logic for selling from user's portfolio

    // Simulate order placement
    const price = orderType === 'Market' ? selectedAsset.price : limitPrice || 0;
    const total = quantity * price;
    setMessage(`Success: ${tradeType} order placed for ${quantity} ${selectedAsset.unit}(s) of ${selectedAsset.name}. Type: ${orderType}. ${orderType === 'Limit' ? `Limit Price: £${limitPrice}.` : ''} Est. Total: £${total.toLocaleString()}`);
    // Reset form partially
    setQuantity(1);
    setLimitPrice('');
  };

  useEffect(() => {
      // Clear message when asset changes
      setMessage('');
      setQuantity(1);
      setLimitPrice('');
  }, [selectedAsset]);


  if (!selectedAsset) {
    return (
      <div className="flex items-center justify-center h-64 bg-white rounded-lg shadow">
        <p className="text-gray-500">Select an asset from the Marketplace to trade.</p>
      </div>
    );
  }

  const price = orderType === 'Market' ? selectedAsset.price : limitPrice || 0;
  const estimatedTotal = quantity > 0 && price > 0 ? (quantity * price).toLocaleString() : '0.00';


  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-800">Trade: {selectedAsset.name}</h1>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Asset Details */}
          <div className="md:col-span-1 bg-white p-6 rounded-lg shadow space-y-3">
              <h2 className="text-xl font-semibold text-gray-800 border-b pb-2 mb-3">Asset Details</h2>
               <p><span className="font-medium text-gray-700">Type:</span> {selectedAsset.type}</p>
               <p><span className="font-medium text-gray-700">Region:</span> {selectedAsset.region}</p>
               <p><span className="font-medium text-gray-700">Unit:</span> {selectedAsset.unit}</p>
               <p><span className="font-medium text-gray-700">Current Price:</span> £{selectedAsset.price.toLocaleString()} / {selectedAsset.unit}</p>
               <p><span className="font-medium text-gray-700">Available:</span> {selectedAsset.available} {selectedAsset.unit}s</p>
               {selectedAsset.expiry && <p><span className="font-medium text-red-600">Expires:</span> {selectedAsset.expiry}</p>}
          </div>

          {/* Order Form */}
          <div className="md:col-span-2 bg-white p-6 rounded-lg shadow space-y-4">
            <h2 className="text-xl font-semibold text-gray-800 border-b pb-2 mb-4">Place Order</h2>

            {/* Trade Type */}
            <div className="flex space-x-2">
                <button onClick={() => setTradeType('Buy')} className={`px-4 py-2 rounded-md text-sm font-medium w-full ${tradeType === 'Buy' ? 'bg-green-600 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}>Buy</button>
                <button onClick={() => setTradeType('Sell')} className={`px-4 py-2 rounded-md text-sm font-medium w-full ${tradeType === 'Sell' ? 'bg-red-600 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}>Sell</button>
            </div>

            {/* Order Type */}
             <div className="flex space-x-2">
                <button onClick={() => setOrderType('Market')} className={`px-4 py-2 rounded-md text-sm font-medium w-full ${orderType === 'Market' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}>Market Order</button>
                <button onClick={() => setOrderType('Limit')} className={`px-4 py-2 rounded-md text-sm font-medium w-full ${orderType === 'Limit' ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700 hover:bg-gray-300'}`}>Limit Order</button>
            </div>

             {/* Quantity */}
             <div>
                <label htmlFor="quantity" className="block text-sm font-medium text-gray-700">Quantity ({selectedAsset.unit}s)</label>
                <input
                    type="number"
                    id="quantity"
                    min="1"
                    step="1"
                    value={quantity}
                    onChange={(e) => setQuantity(Math.max(1, parseInt(e.target.value) || 1))}
                    className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                 />
             </div>

              {/* Limit Price (Conditional) */}
             {orderType === 'Limit' && (
                 <div>
                    <label htmlFor="limitPrice" className="block text-sm font-medium text-gray-700">Limit Price (£ per {selectedAsset.unit})</label>
                    <input
                        type="number"
                        id="limitPrice"
                        min="0.01"
                        step="0.01"
                        value={limitPrice}
                        onChange={(e) => setLimitPrice(parseFloat(e.target.value) || '')}
                        className="mt-1 block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                        placeholder="Enter limit price"
                    />
                 </div>
             )}

              {/* Summary & Submit */}
              <div className="border-t pt-4 space-y-2">
                 <p className="text-sm text-gray-600">Estimated Total: <span className="font-semibold">£{estimatedTotal}</span></p>
                 {/* Add Fee Estimate Here */}
                 <button
                    onClick={handlePlaceOrder}
                    className={`w-full px-4 py-2 rounded-md text-white font-medium ${tradeType === 'Buy' ? 'bg-green-600 hover:bg-green-700' : 'bg-red-600 hover:bg-red-700'} focus:outline-none focus:ring-2 focus:ring-offset-2 ${tradeType === 'Buy' ? 'focus:ring-green-500' : 'focus:ring-red-500'}`}
                  >
                    Place {tradeType} Order
                 </button>
              </div>

              {message && (
                 <div className={`mt-4 p-3 rounded-md text-sm ${message.startsWith('Success') ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                    {message}
                 </div>
              )}
          </div>
        </div>
    </div>
  );
};


// Portfolio Page
const PortfolioPage: React.FC = () => {
  const totalValue = mockPortfolio.reduce((sum, item) => sum + item.currentValue, 0);

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-800">Portfolio</h1>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="bg-white p-4 rounded-lg shadow">
            <h3 className="text-lg font-medium text-gray-700 mb-2">Total Portfolio Value</h3>
            <p className="text-2xl font-semibold text-gray-800">£{totalValue.toLocaleString()}</p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <h3 className="text-lg font-medium text-gray-700 mb-2">Water Balance</h3>
            <p className="text-2xl font-semibold text-blue-600">{mockUserProfile.waterBalanceML} <span className="text-sm font-normal text-gray-500">ML</span></p>
          </div>
          <div className="bg-white p-4 rounded-lg shadow">
            <h3 className="text-lg font-medium text-gray-700 mb-2">Credit Balance</h3>
            <p className="text-2xl font-semibold text-green-600">{mockUserProfile.creditBalance} <span className="text-sm font-normal text-gray-500">Credits</span></p>
          </div>
      </div>

      {/* Holdings Table */}
      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <h2 className="text-xl font-semibold text-gray-800 p-4 border-b">Holdings</h2>
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Asset</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Avg Buy Price</th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Current Value</th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">P/L</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {mockPortfolio.map((item) => {
                const profitLoss = item.currentValue - (item.quantity * item.avgBuyPrice);
                const profitLossPercent = ((item.currentValue / (item.quantity * item.avgBuyPrice)) - 1) * 100;
                return (
                  <tr key={item.assetId} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{item.assetName}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{item.assetType}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-500">{item.quantity.toLocaleString()}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-500">£{item.avgBuyPrice.toLocaleString()}</td>
                    <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-semibold text-gray-900">£{item.currentValue.toLocaleString()}</td>
                    <td className={`px-6 py-4 whitespace-nowrap text-right text-sm font-medium ${profitLoss >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                        £{profitLoss.toLocaleString()} ({profitLossPercent.toFixed(1)}%)
                    </td>
                  </tr>
                );
              })}
               {mockPortfolio.length === 0 && (
                   <tr><td colSpan={6} className="text-center py-5 text-gray-500">No assets currently held.</td></tr>
               )}
            </tbody>
          </table>
        </div>
      </div>

       {/* Trade History Table */}
      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <h2 className="text-xl font-semibold text-gray-800 p-4 border-b">Trade History</h2>
         <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Date</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Asset</th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Price</th>
                <th scope="col" className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Total</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {mockTradeHistory.map((trade) => (
                <tr key={trade.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{trade.date}</td>
                  <td className={`px-6 py-4 whitespace-nowrap text-sm font-medium ${trade.type === 'Buy' ? 'text-green-600' : trade.type === 'Sell' ? 'text-red-600' : 'text-blue-600'}`}>{trade.type}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">{trade.assetName}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-500">{trade.quantity.toLocaleString()}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm text-gray-500">£{trade.price.toLocaleString()}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium text-gray-900">£{trade.total.toLocaleString()}</td>
                </tr>
              ))}
              {mockTradeHistory.length === 0 && (
                   <tr><td colSpan={6} className="text-center py-5 text-gray-500">No trade history found.</td></tr>
               )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};


// Analytics Page
const AnalyticsPage: React.FC = () => {
  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-800">Market Analytics</h1>

      <div className="bg-white p-6 rounded-lg shadow">
        <h2 className="text-xl font-semibold text-gray-800 mb-4">UK Water Index Price Trend (Mock Data)</h2>
        <div className="w-full h-96"> {/* Ensure container has height */}
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={mockMarketData}
              margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0"/>
              <XAxis dataKey="name" stroke="#6b7280" />
              <YAxis stroke="#6b7280" domain={['auto', 'auto']} />
              <Tooltip contentStyle={{ backgroundColor: 'white', border: '1px solid #e0e0e0', borderRadius: '4px' }}/>
              <Legend />
              <Line type="monotone" dataKey="price" stroke="#3b82f6" strokeWidth={2} activeDot={{ r: 8 }} dot={{r:4}}/>
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white p-6 rounded-lg shadow">
           <h2 className="text-xl font-semibold text-gray-800 mb-4">Regional Volume (Mock)</h2>
           <div className="space-y-2">
               <p>London: 15,000 ML traded</p>
               <p>Kent: 500 Credits traded</p>
               <p>Severn: 1 NFT traded</p>
               {/* Add more mock data */}
           </div>
        </div>
         <div className="bg-white p-6 rounded-lg shadow">
           <h2 className="text-xl font-semibold text-gray-800 mb-4">Asset Type Distribution (Mock)</h2>
            {/* Placeholder for Pie Chart or similar */}
             <div className="flex items-center justify-center h-48 bg-gray-100 rounded-md">
                <p className="text-gray-500">Asset Distribution Chart Placeholder</p>
             </div>
        </div>
      </div>

    </div>
  );
};


// Account Page
const AccountPage: React.FC = () => {
  const [userProfile, setUserProfile] = useState<UserProfile>(mockUserProfile);
  const [isEditing, setIsEditing] = useState(false);

  const handleSave = () => {
      // Here you would typically send the updated profile to your backend
      console.log("Saving profile:", userProfile);
      mockUserProfile.name = userProfile.name; // Update mock data (for demo)
      mockUserProfile.email = userProfile.email;
      setIsEditing(false);
  }

  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-gray-800">Account Settings</h1>

      <div className="bg-white p-6 rounded-lg shadow">
         <div className="flex justify-between items-center border-b pb-4 mb-4">
            <h2 className="text-xl font-semibold text-gray-800">Profile Information</h2>
            <button
                onClick={() => isEditing ? handleSave() : setIsEditing(true)}
                className="px-4 py-2 bg-blue-500 text-white text-sm font-medium rounded-md hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
            >
                {isEditing ? 'Save Profile' : 'Edit Profile'}
            </button>
         </div>

        <div className="space-y-4">
            <div>
                <label htmlFor="name" className="block text-sm font-medium text-gray-700">Name</label>
                 <input
                    type="text"
                    id="name"
                    value={userProfile.name}
                    onChange={(e) => setUserProfile({...userProfile, name: e.target.value})}
                    readOnly={!isEditing}
                    className={`mt-1 block w-full px-3 py-2 border rounded-md shadow-sm sm:text-sm ${isEditing ? 'border-gray-300 focus:ring-blue-500 focus:border-blue-500 bg-white' : 'border-gray-200 bg-gray-100 cursor-not-allowed'}`}
                 />
            </div>
             <div>
                <label htmlFor="email" className="block text-sm font-medium text-gray-700">Email</label>
                 <input
                    type="email"
                    id="email"
                    value={userProfile.email}
                    onChange={(e) => setUserProfile({...userProfile, email: e.target.value})}
                    readOnly={!isEditing}
                    className={`mt-1 block w-full px-3 py-2 border rounded-md shadow-sm sm:text-sm ${isEditing ? 'border-gray-300 focus:ring-blue-500 focus:border-blue-500 bg-white' : 'border-gray-200 bg-gray-100 cursor-not-allowed'}`}
                 />
            </div>
            <div>
                <p className="block text-sm font-medium text-gray-700">KYC Status</p>
                <p className={`mt-1 text-sm px-3 py-2 rounded-md inline-block ${
                    userProfile.kycStatus === 'Verified' ? 'bg-green-100 text-green-800' :
                    userProfile.kycStatus === 'Pending' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-red-100 text-red-800'
                }`}>
                    {userProfile.kycStatus}
                     {userProfile.kycStatus !== 'Verified' && <button className="ml-2 text-xs text-blue-600 hover:underline">(Submit Documents)</button>}
                 </p>
                 <p className="mt-1 text-xs text-gray-500">KYC (Know Your Customer) verification is required for higher trading limits.</p>
            </div>
             {/* Add Password Change Section Placeholder */}
             <div className="border-t pt-4">
                 <h3 className="text-lg font-medium text-gray-700">Security</h3>
                 <button className="mt-2 text-sm text-blue-600 hover:underline">Change Password</button><br/>
                 <button className="mt-1 text-sm text-blue-600 hover:underline">Setup Two-Factor Authentication</button>
             </div>
        </div>
      </div>

       {/* Wallet Balances (Read-only view) */}
       <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold text-gray-800 border-b pb-4 mb-4">Wallet Balances</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-blue-50 p-4 rounded-md border border-blue-200">
                    <p className="text-sm font-medium text-blue-700">Water Balance</p>
                    <p className="text-xl font-semibold text-blue-800">{userProfile.waterBalanceML} <span className="text-xs">ML</span></p>
                </div>
                 <div className="bg-green-50 p-4 rounded-md border border-green-200">
                    <p className="text-sm font-medium text-green-700">Credit Balance</p>
                    <p className="text-xl font-semibold text-green-800">{userProfile.creditBalance} <span className="text-xs">Credits</span></p>
                 </div>
                 {/* Could add fiat balance here too */}
            </div>
            <div className="mt-4 space-x-2">
                 <button className="px-3 py-1 bg-gray-200 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-300">Deposit Funds</button>
                 <button className="px-3 py-1 bg-gray-200 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-300">Withdraw Funds</button>
            </div>
       </div>

    </div>
  );
};

// Admin Dashboard Page
const AdminDashboardPage: React.FC = () => {
    const [listingsToApprove, setListingsToApprove] = useState([
        { id: 'new001', name: 'New Thames Temporary Lease', type: 'Water Right - Temporary', user: 'Bob Builder', status: 'Pending'},
        { id: 'new002', name: 'Kent Conservation Credit Batch', type: 'Water Credit - Offset', user: 'Eco Corp', status: 'Pending'},
    ]);

    const handleApproval = (id: string, approve: boolean) => {
        setListingsToApprove(prev => prev.map(listing => listing.id === id ? {...listing, status: approve ? 'Approved' : 'Rejected'} : listing).filter(l => l.status === 'Pending'));
        // In reality, call an API here
        console.log(`Listing ${id} ${approve ? 'Approved' : 'Rejected'}`);
    }


  return (
    <div className="space-y-6">
      <h1 className="text-3xl font-bold text-red-600">Admin Dashboard</h1>

       {/* Pending Listings */}
       <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <h2 className="text-xl font-semibold text-gray-800 p-4 border-b">Pending Listings for Approval</h2>
         <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Listing Name</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Type</th>
                 <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">User</th>
                <th scope="col" className="px-6 py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {listingsToApprove.map((listing) => (
                <tr key={listing.id} className="hover:bg-gray-50">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{listing.name}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{listing.type}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{listing.user}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-center text-sm font-medium space-x-2">
                     <button onClick={() => handleApproval(listing.id, true)} className="text-green-600 hover:text-green-900">Approve</button>
                     <button onClick={() => handleApproval(listing.id, false)} className="text-red-600 hover:text-red-900">Reject</button>
                  </td>
                </tr>
              ))}
               {listingsToApprove.length === 0 && (
                   <tr><td colSpan={4} className="text-center py-5 text-gray-500">No pending listings.</td></tr>
               )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Other Admin Sections Placeholder */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white p-6 rounded-lg shadow">
                <h2 className="text-xl font-semibold text-gray-800 mb-4">User Management</h2>
                <p className="text-sm text-gray-500">View users, manage KYC status, suspend accounts.</p>
                <button className="mt-2 px-3 py-1 bg-gray-200 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-300">Manage Users</button>
          </div>
           <div className="bg-white p-6 rounded-lg shadow">
                <h2 className="text-xl font-semibold text-gray-800 mb-4">Trade Monitoring</h2>
                <p className="text-sm text-gray-500">View recent trades, flag suspicious activity.</p>
                <button className="mt-2 px-3 py-1 bg-gray-200 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-300">View Trades</button>
          </div>
          <div className="bg-white p-6 rounded-lg shadow">
                <h2 className="text-xl font-semibold text-gray-800 mb-4">Platform Settings</h2>
                <p className="text-sm text-gray-500">Adjust trading fees, manage asset types, set regional rules.</p>
                <button className="mt-2 px-3 py-1 bg-gray-200 text-gray-700 text-sm font-medium rounded-md hover:bg-gray-300">Configure Settings</button>
          </div>
           <div className="bg-white p-6 rounded-lg shadow">
                <h2 className="text-xl font-semibold text-gray-800 mb-4">Supply Adjustment</h2>
                <p className="text-sm text-gray-500">Manually adjust available volumes for certain assets (e.g., government allocations).</p>
                 <button className="mt-2 px-3 py-1 bg-red-100 text-red-700 text-sm font-medium rounded-md hover:bg-red-200">Adjust Supply</button>
          </div>
      </div>
    </div>
  );
};


// --- Main App Component ---
const WaterTradingApp: React.FC = () => {
  const [currentPage, setCurrentPage] = useState<string>('Dashboard');
  const [selectedAsset, setSelectedAsset] = useState<WaterAsset | null>(null);

  const renderPage = () => {
    switch (currentPage) {
      case 'Dashboard':
        return <DashboardPage />;
      case 'Marketplace':
        return <MarketplacePage setSelectedAsset={setSelectedAsset} setPage={setCurrentPage} />;
      case 'Trade':
        return <TradingPage selectedAsset={selectedAsset} />;
      case 'Portfolio':
        return <PortfolioPage />;
      case 'Analytics':
        return <AnalyticsPage />;
      case 'Account':
        return <AccountPage />;
      case 'Admin':
        return <AdminDashboardPage />;
      default:
        return <DashboardPage />;
    }
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <Navbar setPage={setCurrentPage} currentPage={currentPage} />
      <main>
        <div className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8">
          {/* Page content */}
          <div className="px-4 py-6 sm:px-0">
            {renderPage()}
          </div>
          {/* /End replace */}
        </div>
      </main>
    </div>
  );
};

export default WaterTradingApp;